sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("Version.Version.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map